#include <stdio.h>
#include <stdlib.h>


int main() {
	char letra = 'a'; // Iniciamos la letra "a"
	letra = letra + 2; // Sumamos 1 a la letra



	printf("%i\n", letra); // Imprime el valor ASCII de la letra
	printf("%i\n", letra); // Imprime la letra resultante





	return 0;
}
