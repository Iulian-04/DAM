#include<stdio.h>
#include<stdlib.h>

int main(){
	char h = 'h';
	char o = 'o';
	char l = 'l';
	char a = 'a';

	char a = 'a';
	char d = 'd';
	char i = 'i';
	char o = 'o';
	char s = 's';

	// Imprimir "hola"
	// printf("%c%c%c%c\n", h, o, l, a);

       	// Imprimir "adiós"
	// printf("%c%c%c%c%c\n", a, d, i, o, s);


	return 0;


}                               
